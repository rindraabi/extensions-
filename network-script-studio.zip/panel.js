/* Network Script Studio
 * DevTools-only network inspector. All processing happens locally in this panel.
 * Sensitive headers, cookie values, credentials, and sensitive parameters are masked.
 */

const state = {
  records: [],
  selectedId: null,
  activeTab: 'overview',
  capturing: true,
  generatedCode: '',
  saved: []
};

const SENSITIVE_KEY_RE = /(authorization|proxy-authorization|cookie|set-cookie|token|secret|api[-_]?key|password|passwd|passphrase|session|csrf|xsrf|signature|access[-_]?token|refresh[-_]?token|client[-_]?secret|private[-_]?key)/i;
const SAFE_HEADER_RE = /^(accept|accept-language|content-type|user-agent|origin|referer|x-requested-with)$/i;
const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => Array.from(document.querySelectorAll(selector));

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function escapeJsString(value) {
  return JSON.stringify(value ?? '');
}

function escapePhpSingle(value) {
  return String(value ?? '').replaceAll('\\', '\\\\').replaceAll("'", "\\'");
}

function className(value) {
  const cleaned = String(value || 'GeneratedApiClient')
    .replace(/[^a-zA-Z0-9_]/g, ' ')
    .split(/\s+/)
    .filter(Boolean)
    .map(part => part.charAt(0).toUpperCase() + part.slice(1))
    .join('');
  return /^[A-Za-z_]/.test(cleaned) ? cleaned : `Client${cleaned || 'Api'}`;
}

function functionNameFromUrl(url, method) {
  try {
    const parsed = new URL(url);
    const parts = parsed.pathname.split('/').filter(Boolean).slice(-2);
    const suffix = parts.join(' ') || 'request';
    const base = `${method.toLowerCase()} ${suffix}`
      .replace(/[^a-zA-Z0-9]+/g, ' ')
      .trim()
      .split(/\s+/)
      .map((word, index) => index === 0 ? word.toLowerCase() : word.charAt(0).toUpperCase() + word.slice(1))
      .join('');
    return /^[a-zA-Z_]/.test(base) ? base : 'executeRequest';
  } catch {
    return 'executeRequest';
  }
}

function formatBytes(value) {
  const bytes = Number(value || 0);
  if (!Number.isFinite(bytes) || bytes <= 0) return '—';
  const units = ['B', 'KB', 'MB', 'GB'];
  let index = 0;
  let current = bytes;
  while (current >= 1024 && index < units.length - 1) {
    current /= 1024;
    index += 1;
  }
  return `${current.toFixed(current >= 10 || index === 0 ? 0 : 1)} ${units[index]}`;
}

function formatMs(value) {
  const ms = Number(value || 0);
  if (!Number.isFinite(ms) || ms < 0) return '—';
  return ms >= 1000 ? `${(ms / 1000).toFixed(2)} s` : `${Math.round(ms)} ms`;
}

function inferType(entry) {
  const explicit = String(entry._resourceType || entry.resourceType || '').toLowerCase();
  if (explicit) return explicit;
  const mime = String(entry.response?.content?.mimeType || '').toLowerCase();
  if (mime.includes('json')) return 'fetch/xhr';
  if (mime.includes('javascript')) return 'script';
  if (mime.includes('html')) return 'document';
  if (mime.includes('css')) return 'stylesheet';
  if (mime.startsWith('image/')) return 'image';
  if (mime.startsWith('font/')) return 'font';
  return 'other';
}

function isApiRequest(entry) {
  const type = inferType(entry);
  const url = String(entry.request?.url || '').toLowerCase();
  const mime = String(entry.response?.content?.mimeType || '').toLowerCase();
  return /xhr|fetch/.test(type) || mime.includes('json') || /\/api\/|graphql|ajax/.test(url);
}

function methodClass(method) {
  return `method-${String(method || 'GET').toLowerCase()}`;
}

function statusClass(status) {
  const code = Number(status || 0);
  if (code >= 400) return 'status-error';
  if (code >= 300) return 'status-warning';
  return 'status-ok';
}

function isSensitiveKey(key) {
  return SENSITIVE_KEY_RE.test(String(key || ''));
}

function maskValue(value, label = 'REDACTED') {
  const text = String(value ?? '');
  if (!text) return `[${label}]`;
  if (text.length <= 6) return `[${label}]`;
  return `${text.slice(0, 3)}••••${text.slice(-2)} [${label}]`;
}

function sanitizeHeader(header) {
  const name = String(header?.name || '');
  const value = String(header?.value || '');
  if (isSensitiveKey(name)) {
    return { name, value: maskValue(value), masked: true };
  }
  return { name, value, masked: false };
}

function getSafeHeaders(headers) {
  return (headers || [])
    .filter(header => SAFE_HEADER_RE.test(String(header?.name || '')) && !isSensitiveKey(header?.name))
    .map(header => ({ name: String(header.name), value: String(header.value || '') }));
}

function deepSanitize(value, inheritedKey = '') {
  if (Array.isArray(value)) return value.map(item => deepSanitize(item, inheritedKey));
  if (value && typeof value === 'object') {
    const output = {};
    Object.entries(value).forEach(([key, item]) => {
      output[key] = isSensitiveKey(key) ? 'YOUR_SECRET_HERE' : deepSanitize(item, key);
    });
    return output;
  }
  if (isSensitiveKey(inheritedKey)) return 'YOUR_SECRET_HERE';
  return value;
}

function sanitizeTextBody(text, mime = '') {
  const raw = String(text ?? '');
  if (!raw) return '';
  const isJson = /json/i.test(mime) || /^[\s\[{]/.test(raw);
  if (isJson) {
    try {
      return JSON.stringify(deepSanitize(JSON.parse(raw)), null, 2);
    } catch {
      // Continue to key/value masking when JSON is malformed or not complete.
    }
  }

  return raw
    .replace(/(["']?(?:password|passwd|token|secret|api[_-]?key|authorization|cookie|session|signature)["']?\s*[:=]\s*)(["'][^"']*["']|[^&\s,}\]]+)/gi, '$1YOUR_SECRET_HERE')
    .replace(/(Bearer\s+)[A-Za-z0-9._~+\/-]+=*/gi, '$1YOUR_TOKEN_HERE');
}

function sanitizeUrl(rawUrl) {
  try {
    const parsed = new URL(rawUrl);
    for (const [key] of parsed.searchParams.entries()) {
      if (isSensitiveKey(key)) parsed.searchParams.set(key, 'YOUR_SECRET_HERE');
    }
    return parsed.toString();
  } catch {
    return String(rawUrl || '');
  }
}

function payloadInfo(entry) {
  const postData = entry.request?.postData;
  if (!postData) return { exists: false, mime: '', raw: '', sanitized: '', json: null, params: [] };
  const mime = String(postData.mimeType || '');
  const raw = String(postData.text || '');
  const params = Array.isArray(postData.params) ? postData.params.map(param => ({
    name: String(param.name || ''),
    value: isSensitiveKey(param.name) ? 'YOUR_SECRET_HERE' : String(param.value || ''),
    fileName: param.fileName ? String(param.fileName) : null
  })) : [];
  const sanitized = sanitizeTextBody(raw, mime);
  let json = null;
  if (sanitized && /json/i.test(mime)) {
    try { json = JSON.parse(sanitized); } catch { json = null; }
  }
  return { exists: true, mime, raw, sanitized, json, params };
}

function requestId(entry, index = 0) {
  return `${entry.startedDateTime || Date.now()}|${entry.request?.method || ''}|${entry.request?.url || ''}|${index}|${Math.random().toString(16).slice(2)}`;
}

function currentRecord() {
  return state.records.find(record => record.id === state.selectedId) || null;
}

function recordSnapshot(record) {
  const entry = record.entry;
  const payload = payloadInfo(entry);
  return {
    id: `saved_${Date.now()}_${Math.random().toString(16).slice(2)}`,
    method: String(entry.request?.method || 'GET'),
    url: sanitizeUrl(entry.request?.url || ''),
    status: Number(entry.response?.status || 0),
    statusText: String(entry.response?.statusText || ''),
    mimeType: String(entry.response?.content?.mimeType || ''),
    resourceType: inferType(entry),
    safeHeaders: getSafeHeaders(entry.request?.headers || []),
    payload: payload.sanitized,
    payloadMime: payload.mime,
    savedAt: new Date().toISOString()
  };
}

function snapshotToRecord(snapshot) {
  const entry = {
    startedDateTime: snapshot.savedAt || new Date().toISOString(),
    time: 0,
    request: {
      method: snapshot.method || 'GET',
      url: snapshot.url || '',
      headers: snapshot.safeHeaders || [],
      postData: snapshot.payload ? { mimeType: snapshot.payloadMime || 'application/json', text: snapshot.payload } : undefined
    },
    response: {
      status: snapshot.status || 0,
      statusText: snapshot.statusText || '',
      headers: [],
      content: { mimeType: snapshot.mimeType || '', text: '' }
    },
    _resourceType: snapshot.resourceType || 'saved'
  };
  return { id: `restored_${snapshot.id}`, entry, content: null, contentEncoding: '', contentLoaded: true, savedSnapshot: true };
}

function addRecord(entry) {
  const duplicate = state.records.some(record =>
    record.entry.request?.url === entry.request?.url &&
    record.entry.request?.method === entry.request?.method &&
    record.entry.startedDateTime === entry.startedDateTime
  );
  if (duplicate) return;

  state.records.push({
    id: requestId(entry, state.records.length),
    entry,
    content: null,
    contentEncoding: '',
    contentLoaded: false,
    savedSnapshot: false
  });
  renderAll();
}

function loadHar() {
  chrome.devtools.network.getHAR(harLog => {
    const entries = Array.isArray(harLog?.entries) ? harLog.entries : [];
    entries.forEach(addRecord);
    showToast(`${entries.length} HAR request dibaca.`);
  });
}

function clearRecords() {
  state.records = [];
  state.selectedId = null;
  state.generatedCode = '';
  renderAll();
  showToast('Capture list dibersihkan.');
}

function filteredRecords() {
  const query = $('#searchInput').value.trim().toLowerCase();
  const method = $('#methodFilter').value;
  const statusGroup = $('#statusFilter').value;
  return state.records.filter(record => {
    const entry = record.entry;
    const url = String(entry.request?.url || '').toLowerCase();
    const currentMethod = String(entry.request?.method || 'GET').toUpperCase();
    const status = Number(entry.response?.status || 0);
    if (query && !url.includes(query)) return false;
    if (method && currentMethod !== method) return false;
    if (statusGroup && String(status).charAt(0) !== statusGroup) return false;
    return true;
  });
}

function renderStats() {
  const all = state.records;
  $('#statTotal').textContent = String(all.length);
  $('#statApi').textContent = String(all.filter(record => isApiRequest(record.entry)).length);
  $('#statErrors').textContent = String(all.filter(record => Number(record.entry.response?.status || 0) >= 400).length);
  $('#statCapture').textContent = state.capturing ? 'ON' : 'OFF';
}

function renderList() {
  const tbody = $('#requestTableBody');
  const records = filteredRecords();
  if (!records.length) {
    tbody.innerHTML = '<tr><td colspan="7" class="empty-state">Tidak ada request yang sesuai filter. Refresh halaman target bila daftar masih kosong.</td></tr>';
    return;
  }

  tbody.innerHTML = records.map(record => {
    const entry = record.entry;
    const method = String(entry.request?.method || 'GET').toUpperCase();
    const url = sanitizeUrl(entry.request?.url || '');
    const status = Number(entry.response?.status || 0);
    const type = inferType(entry);
    const size = entry.response?.bodySize > 0 ? entry.response.bodySize : entry.response?.content?.size;
    return `
      <tr data-id="${escapeHtml(record.id)}" class="${record.id === state.selectedId ? 'selected' : ''}">
        <td><span class="method-badge ${methodClass(method)}">${escapeHtml(method)}</span></td>
        <td title="${escapeHtml(url)}"><div class="endpoint">${escapeHtml(url)}</div></td>
        <td><span class="status-badge ${statusClass(status)}">${status || '—'}</span></td>
        <td><span class="type-badge">${escapeHtml(type)}</span></td>
        <td>${formatBytes(size)}</td>
        <td>${formatMs(entry.time)}</td>
        <td><button class="btn btn-outline small choose-request" data-id="${escapeHtml(record.id)}">Inspect</button></td>
      </tr>`;
  }).join('');
}

function setSelected(id) {
  if (!state.records.some(record => record.id === id)) return;
  state.selectedId = id;
  $('#saveBtn').disabled = false;
  $('#generateJumpBtn').disabled = false;
  $('#generateBtn').disabled = false;
  renderList();
  renderDetailMeta();
  renderActiveTab();
  generateCode();
}

function renderDetailMeta() {
  const record = currentRecord();
  if (!record) {
    $('#detailTitle').textContent = 'Detail request';
    $('#detailSubtitle').textContent = 'Pilih request dari tabel untuk melihat header, payload, preview, response, cookie, dan timing.';
    return;
  }
  const entry = record.entry;
  $('#detailTitle').textContent = `${String(entry.request?.method || 'GET').toUpperCase()} • ${sanitizeUrl(entry.request?.url || '')}`;
  $('#detailSubtitle').textContent = `Status ${entry.response?.status || '—'} • ${inferType(entry)} • ${formatMs(entry.time)} • ${formatBytes(entry.response?.content?.size || entry.response?.bodySize)}`;
}

function kv(label, value, code = false) {
  return `<div class="kv"><span>${escapeHtml(label)}</span>${code ? `<code title="${escapeHtml(value)}">${escapeHtml(value)}</code>` : `<b title="${escapeHtml(value)}">${escapeHtml(value)}</b>`}</div>`;
}

function renderOverview(record) {
  const entry = record.entry;
  const request = entry.request || {};
  const response = entry.response || {};
  const url = sanitizeUrl(request.url || '');
  let host = '—';
  let protocol = '—';
  try {
    const parsed = new URL(url);
    host = parsed.host;
    protocol = parsed.protocol.replace(':', '').toUpperCase();
  } catch { /* no-op */ }
  return `<div class="kv-grid">
    ${kv('URL', url, true)}
    ${kv('Method', request.method || 'GET')}
    ${kv('Status', `${response.status || '—'} ${response.statusText || ''}`)}
    ${kv('Domain', host)}
    ${kv('Protocol', protocol)}
    ${kv('Resource type', inferType(entry))}
    ${kv('Started', entry.startedDateTime || '—')}
    ${kv('Duration', formatMs(entry.time))}
    ${kv('Response size', formatBytes(response.content?.size || response.bodySize))}
    ${kv('MIME type', response.content?.mimeType || '—')}
    ${kv('Redirect URL', response.redirectURL || '—', true)}
    ${kv('Initiator', entry._initiator?.type || entry._initiator?.url || 'Browser')}
  </div>`;
}

function headersHtml(title, headers) {
  const list = headers || [];
  if (!list.length) return `<div class="headers-group"><h3>${escapeHtml(title)}</h3><p class="muted">Tidak tersedia.</p></div>`;
  return `<div class="headers-group"><h3>${escapeHtml(title)}</h3><div class="header-list">${list.map(item => {
    const header = sanitizeHeader(item);
    return `<div class="header-row"><span class="header-key">${escapeHtml(header.name)}</span><span class="header-value ${header.masked ? 'masked' : ''}">${escapeHtml(header.value)}</span></div>`;
  }).join('')}</div></div>`;
}

function renderHeaders(record) {
  const entry = record.entry;
  let queryRows = [];
  try {
    const url = new URL(entry.request?.url || '');
    queryRows = Array.from(url.searchParams.entries()).map(([name, value]) => ({ name, value: isSensitiveKey(name) ? 'YOUR_SECRET_HERE' : value }));
  } catch { /* no-op */ }
  return `<div class="notice">Header rahasia seperti Authorization, Cookie, API key, token, password, dan session selalu ditampilkan dalam bentuk tersensor.</div>
    ${headersHtml('Request headers', entry.request?.headers || [])}
    ${headersHtml('Response headers', entry.response?.headers || [])}
    ${headersHtml('Query parameters', queryRows)}`;
}

function renderPayload(record) {
  const info = payloadInfo(record.entry);
  if (!info.exists) return '<p class="empty-state">Request ini tidak memiliki payload/body.</p>';
  let params = '';
  if (info.params.length) {
    params = `<div class="headers-group"><h3>Form parameters</h3><div class="header-list">${info.params.map(param => `<div class="header-row"><span class="header-key">${escapeHtml(param.name)}</span><span class="header-value ${isSensitiveKey(param.name) ? 'masked' : ''}">${escapeHtml(param.fileName ? `[file] ${param.fileName}` : param.value)}</span></div>`).join('')}</div></div>`;
  }
  return `<div class="mini-title">Content-Type: ${escapeHtml(info.mime || 'unknown')}</div>${params}<pre class="code-block">${escapeHtml(info.sanitized || '(Payload biner atau tidak tersedia)')}</pre>`;
}

function getContent(record) {
  if (!record || record.contentLoaded) return Promise.resolve(record?.content || '');
  const entry = record.entry;
  if (!entry || typeof entry.getContent !== 'function') {
    record.contentLoaded = true;
    record.content = '';
    return Promise.resolve('');
  }
  return new Promise(resolve => {
    try {
      entry.getContent((content, encoding) => {
        record.content = String(content || '');
        record.contentEncoding = String(encoding || '');
        record.contentLoaded = true;
        resolve(record.content);
      });
    } catch {
      record.contentLoaded = true;
      record.content = '';
      resolve('');
    }
  });
}

function renderContentText(record) {
  const mime = String(record.entry.response?.content?.mimeType || '');
  const text = String(record.content || '');
  if (!text) return '<p class="empty-state">Content response tidak tersedia. Buka DevTools sebelum reload halaman target, lalu capture ulang request.</p>';
  if (/json/i.test(mime)) {
    try { return `<pre class="code-block">${escapeHtml(JSON.stringify(JSON.parse(text), null, 2))}</pre>`; } catch { /* use raw */ }
  }
  return `<pre class="code-block">${escapeHtml(text)}</pre>`;
}

async function renderPreview(record) {
  await getContent(record);
  if (currentRecord()?.id !== record.id || state.activeTab !== 'preview') return;
  const mime = String(record.entry.response?.content?.mimeType || '').toLowerCase();
  const text = String(record.content || '');
  if (!text) {
    $('#tabContent').innerHTML = '<p class="empty-state">Preview tidak tersedia untuk request ini.</p>';
    return;
  }
  if (mime.includes('html')) {
    const safeHtml = text.replace(/<script[\s\S]*?<\/script>/gi, '').replace(/on\w+\s*=\s*["'][^"']*["']/gi, '');
    $('#tabContent').innerHTML = `<div class="notice">HTML ditampilkan di iframe sandbox dan script dihilangkan.</div><iframe class="response-frame" sandbox="" srcdoc="${escapeHtml(safeHtml)}"></iframe>`;
    return;
  }
  if (mime.startsWith('image/')) {
    const encoding = record.contentEncoding || '';
    const src = encoding === 'base64' ? `data:${mime};base64,${text}` : text;
    $('#tabContent').innerHTML = `<img alt="Response preview" style="max-width:100%;max-height:420px;border-radius:8px;border:1px solid rgba(134,164,255,.16)" src="${escapeHtml(src)}">`;
    return;
  }
  $('#tabContent').innerHTML = renderContentText(record);
}

async function renderResponse(record) {
  await getContent(record);
  if (currentRecord()?.id !== record.id || state.activeTab !== 'response') return;
  const encoding = record.contentEncoding ? ` • Encoding: ${escapeHtml(record.contentEncoding)}` : '';
  $('#tabContent').innerHTML = `<div class="mini-title">${escapeHtml(record.entry.response?.content?.mimeType || 'Response body')}${encoding}</div>${renderContentText(record)}`;
}

function parseCookieNames(headers, source) {
  const items = [];
  (headers || []).forEach(header => {
    const name = String(header.name || '');
    if (/^cookie$/i.test(name)) {
      String(header.value || '').split(';').forEach(piece => {
        const [cookieName] = piece.trim().split('=');
        if (cookieName) items.push({ source, name: cookieName, detail: 'Nilai cookie disembunyikan.' });
      });
    }
    if (/^set-cookie$/i.test(name)) {
      const first = String(header.value || '').split(';')[0];
      const [cookieName] = first.split('=');
      if (cookieName) items.push({ source, name: cookieName.trim(), detail: 'Nilai Set-Cookie disembunyikan.' });
    }
  });
  return items;
}

function renderCookies(record) {
  const requestCookies = parseCookieNames(record.entry.request?.headers || [], 'Request');
  const responseCookies = parseCookieNames(record.entry.response?.headers || [], 'Response');
  const all = [...requestCookies, ...responseCookies];
  if (!all.length) return '<p class="empty-state">Tidak ada cookie yang terlihat pada HAR header request ini, atau browser tidak mengeksposnya.</p>';
  return `<div class="notice">Ekstensi ini tidak meminta izin membaca cookie browser. Hanya nama cookie yang muncul di header HAR ditampilkan; nilainya tidak pernah ditampilkan atau diekspor.</div>${all.map(cookie => `<article class="cookie-card"><b>${escapeHtml(cookie.name)}</b><p>${escapeHtml(cookie.source)} • ${escapeHtml(cookie.detail)}</p></article>`).join('')}`;
}

function renderTiming(record) {
  const timings = record.entry.timings || {};
  const parts = [
    ['Blocked', timings.blocked], ['DNS', timings.dns], ['Connect', timings.connect], ['SSL', timings.ssl],
    ['Send', timings.send], ['Wait', timings.wait], ['Receive', timings.receive]
  ].map(([name, value]) => [name, Math.max(0, Number(value || 0))]);
  const max = Math.max(1, ...parts.map(([, value]) => value));
  return `<div class="mini-title">Total: ${formatMs(record.entry.time)}</div>${parts.map(([name, value]) => `<div class="timing-row"><span>${escapeHtml(name)}</span><div class="timing-bar-wrap"><div class="timing-bar" style="width:${Math.max(2, (value / max) * 100)}%"></div></div><span class="timing-value">${formatMs(value)}</span></div>`).join('')}`;
}

function renderActiveTab() {
  const record = currentRecord();
  const content = $('#tabContent');
  if (!record) {
    content.innerHTML = '<p class="empty-state">Pilih request terlebih dahulu.</p>';
    return;
  }
  if (state.activeTab === 'overview') content.innerHTML = renderOverview(record);
  if (state.activeTab === 'headers') content.innerHTML = renderHeaders(record);
  if (state.activeTab === 'payload') content.innerHTML = renderPayload(record);
  if (state.activeTab === 'cookies') content.innerHTML = renderCookies(record);
  if (state.activeTab === 'timing') content.innerHTML = renderTiming(record);
  if (state.activeTab === 'preview') {
    content.innerHTML = '<p class="empty-state">Memuat preview response…</p>';
    renderPreview(record);
  }
  if (state.activeTab === 'response') {
    content.innerHTML = '<p class="empty-state">Memuat response body…</p>';
    renderResponse(record);
  }
}

function descriptorFor(record) {
  const entry = record.entry;
  const payload = payloadInfo(entry);
  return {
    url: sanitizeUrl(entry.request?.url || ''),
    method: String(entry.request?.method || 'GET').toUpperCase(),
    safeHeaders: $('#safeHeadersToggle').checked ? getSafeHeaders(entry.request?.headers || []) : [],
    payload,
    mime: String(payload.mime || entry.request?.headers?.find(h => /^content-type$/i.test(h.name || ''))?.value || ''),
    functionName: functionNameFromUrl(entry.request?.url || '', entry.request?.method || 'GET')
  };
}

function phpArray(items, indent = '        ') {
  if (!items.length) return '[]';
  return `[\n${items.map(item => `${indent}'${escapePhpSingle(item.name)}: ${escapePhpSingle(item.value)}',`).join('\n')}\n    ]`;
}

function phpPayloadLiteral(payload) {
  if (!payload.exists || !payload.sanitized) return 'null';
  if (payload.json) {
    // json_decode keeps the generated PHP valid for nested JSON objects and arrays.
    return `json_decode('${escapePhpSingle(JSON.stringify(payload.json))}', true)`;
  }
  return `'${escapePhpSingle(payload.sanitized)}'`;
}

function generatePhp(descriptor, customClass, includeParse) {
  const headers = phpArray(descriptor.safeHeaders);
  const isJson = /json/i.test(descriptor.mime);
  const examplePayload = phpPayloadLiteral(descriptor.payload);
  const useBody = ['POST', 'PUT', 'PATCH', 'DELETE'].includes(descriptor.method);
  const parseCode = includeParse
    ? `        $decoded = json_decode($response, true);\n        $data = json_last_error() === JSON_ERROR_NONE ? $decoded : $response;`
    : '        $data = $response;';

  return `<?php
/**
 * Generated by Network Script Studio.
 * Source request: ${descriptor.method} ${descriptor.url}
 * Security: Cookie, Authorization, token, API key, password, and session values
 * are intentionally not copied. Supply your own credentials only for systems you own or may test.
 */
class ${customClass}
{
    private $endpoint = '${escapePhpSingle(descriptor.url)}';
    private $method = '${descriptor.method}';
    private $timeout = 30;
    private $defaultHeaders = ${headers};

    public function setBearerToken($token)
    {
        // Use only credentials for your own authorized API.
        $this->defaultHeaders[] = 'Authorization: Bearer ' . $token;
        return $this;
    }

    private function buildUrl($query)
    {
        if (empty($query)) {
            return $this->endpoint;
        }

        $separator = strpos($this->endpoint, '?') === false ? '?' : '&';
        return $this->endpoint . $separator . http_build_query($query);
    }

    public function ${descriptor.functionName}($query = [], $body = null)
    {
        $ch = curl_init();
        $headers = $this->defaultHeaders;
        $url = $this->buildUrl($query);

        $options = [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_CUSTOMREQUEST => $this->method,
            CURLOPT_HTTPHEADER => $headers,
            // SSL verification stays enabled for production safety.
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ];

        if ($body !== null && in_array($this->method, ['POST', 'PUT', 'PATCH', 'DELETE'], true)) {
            if (is_array($body)) {
                $body = json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                if (!in_array('Content-Type: application/json', $headers, true)) {
                    $headers[] = 'Content-Type: application/json';
                    $options[CURLOPT_HTTPHEADER] = $headers;
                }
            }
            $options[CURLOPT_POSTFIELDS] = $body;
        }

        curl_setopt_array($ch, $options);
        $response = curl_exec($ch);
        $curlError = curl_error($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $contentType = (string) curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
        curl_close($ch);

        if ($curlError) {
            throw new RuntimeException('cURL error: ' . $curlError);
        }

${parseCode}

        return [
            'status' => $httpCode,
            'content_type' => $contentType,
            'data' => $data,
        ];
    }
}

// Example usage:
try {
    $client = new ${customClass}();
    // $client->setBearerToken('YOUR_TOKEN_HERE');
    $result = $client->${descriptor.functionName}([], ${useBody ? examplePayload : 'null'});
    echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
`;
}

function pythonDict(headers, indent = '            ') {
  if (!headers.length) return '{}';
  return `{\n${headers.map(item => `${indent}${escapeJsString(item.name)}: ${escapeJsString(item.value)},`).join('\n')}\n        }`;
}

function pythonPayloadLiteral(payload) {
  if (!payload.exists || !payload.sanitized) return 'None';
  if (payload.json) {
    // json.loads preserves values such as true/false/null and nested structures safely.
    return `json.loads(${escapeJsString(JSON.stringify(payload.json))})`;
  }
  return escapeJsString(payload.sanitized);
}

function generatePython(descriptor, customClass, includeParse) {
  const headers = pythonDict(descriptor.safeHeaders);
  const bodyLiteral = pythonPayloadLiteral(descriptor.payload);
  const isJson = /json/i.test(descriptor.mime);
  const parseCode = includeParse
    ? `        try:\n            data = response.json()\n        except ValueError:\n            data = response.text`
    : '        data = response.text';
  return `"""
Generated by Network Script Studio.
Source request: ${descriptor.method} ${descriptor.url}
Sensitive headers and values were intentionally excluded.
"""
import json
import requests


class ${customClass}:
    def __init__(self, timeout=30):
        self.endpoint = ${escapeJsString(descriptor.url)}
        self.method = ${escapeJsString(descriptor.method)}
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update(${headers})

    def set_bearer_token(self, token):
        # Use only a token for an API that you own or are authorized to test.
        self.session.headers['Authorization'] = f'Bearer {token}'
        return self

    def ${descriptor.functionName}(self, query=None, body=None):
        request_kwargs = {
            'params': query or {},
            'timeout': self.timeout,
            'allow_redirects': True,
        }

        if body is not None:
            ${isJson ? "request_kwargs['json'] = body" : "request_kwargs['data'] = body"}

        try:
            response = self.session.request(self.method, self.endpoint, **request_kwargs)
            response.raise_for_status()
${parseCode}
            return {
                'status': response.status_code,
                'content_type': response.headers.get('content-type', ''),
                'data': data,
            }
        except requests.RequestException as error:
            raise RuntimeError(f'Request failed: {error}') from error


if __name__ == '__main__':
    client = ${customClass}()
    # client.set_bearer_token('YOUR_TOKEN_HERE')
    result = client.${descriptor.functionName}(query={}, body=${bodyLiteral})
    print(result)
`;
}

function shellQuote(value) {
  return `'${String(value ?? '').replaceAll("'", "'\\''")}'`;
}

function generateCurl(descriptor) {
  const lines = [
    `curl --request ${descriptor.method} \\`,
    `  --url ${shellQuote(descriptor.url)} \\`,
    '  --max-time 30 \\',
    '  --location'
  ];
  descriptor.safeHeaders.forEach(header => {
    lines[lines.length - 1] += ' \\';
    lines.push(`  --header ${shellQuote(`${header.name}: ${header.value}`)}`);
  });
  if (descriptor.payload.exists && descriptor.payload.sanitized) {
    lines[lines.length - 1] += ' \\';
    lines.push(`  --data-raw ${shellQuote(descriptor.payload.sanitized)}`);
  }
  lines.push('', '# Sensitive credentials were intentionally excluded.');
  lines.push('# Add your own Authorization header only for an API you own or are authorized to test.');
  return lines.join('\n');
}

function generateCode() {
  const record = currentRecord();
  if (!record) {
    $('#codeOutput').textContent = '// Pilih request untuk membuat script.';
    $('#codeLabel').textContent = 'Pilih request untuk membuat script.';
    $('#copyCodeBtn').disabled = true;
    $('#downloadCodeBtn').disabled = true;
    state.generatedCode = '';
    return;
  }
  const descriptor = descriptorFor(record);
  const language = $('#languageSelect').value;
  const customClass = className($('#classNameInput').value);
  const includeParse = $('#sampleParseToggle').checked;

  state.generatedCode = language === 'php'
    ? generatePhp(descriptor, customClass, includeParse)
    : language === 'python'
      ? generatePython(descriptor, customClass, includeParse)
      : generateCurl(descriptor);

  $('#codeOutput').textContent = state.generatedCode;
  $('#codeLabel').textContent = `${language === 'php' ? 'PHP cURL Class' : language === 'python' ? 'Python 3 requests Class' : 'cURL Command'} • ${descriptor.method} ${descriptor.url}`;
  $('#copyCodeBtn').disabled = false;
  $('#downloadCodeBtn').disabled = false;
}

function filenameForCode() {
  const language = $('#languageSelect').value;
  if (language === 'php') return 'generated_api_client.php';
  if (language === 'python') return 'generated_api_client.py';
  return 'generated_request.sh';
}

function mimeForCode() {
  const language = $('#languageSelect').value;
  if (language === 'php') return 'text/x-php;charset=utf-8';
  if (language === 'python') return 'text/x-python;charset=utf-8';
  return 'text/x-shellscript;charset=utf-8';
}

function showToast(message, isError = false) {
  const toast = $('#toast');
  toast.textContent = message;
  toast.classList.toggle('error', isError);
  toast.classList.add('show');
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove('show'), 2600);
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    $('#copyStatus').textContent = 'Copied.';
    showToast('Kode berhasil disalin.');
  } catch {
    showToast('Clipboard tidak tersedia. Salin kode secara manual.', true);
  }
}

function downloadText(filename, text, mime) {
  const blob = new Blob([text], { type: mime });
  const href = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = href;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(href), 1000);
}

async function loadSaved() {
  const data = await chrome.storage.local.get({ savedRequests: [] });
  state.saved = Array.isArray(data.savedRequests) ? data.savedRequests : [];
  renderSaved();
}

async function saveCurrent() {
  const record = currentRecord();
  if (!record) return;
  const snapshot = recordSnapshot(record);
  state.saved.unshift(snapshot);
  await chrome.storage.local.set({ savedRequests: state.saved });
  renderSaved();
  showToast('Snapshot tersensor disimpan lokal.');
}

async function removeSaved(id) {
  state.saved = state.saved.filter(item => item.id !== id);
  await chrome.storage.local.set({ savedRequests: state.saved });
  renderSaved();
  showToast('Saved snapshot dihapus.');
}

async function clearSaved() {
  state.saved = [];
  await chrome.storage.local.set({ savedRequests: [] });
  renderSaved();
  showToast('Semua saved snapshot dihapus.');
}

function renderSaved() {
  const root = $('#savedList');
  if (!state.saved.length) {
    root.innerHTML = '<p class="empty-state">Belum ada request yang disimpan.</p>';
    return;
  }
  root.innerHTML = state.saved.map(item => `
    <article class="saved-item">
      <div><code>${escapeHtml(item.method)} ${escapeHtml(item.url)}</code><small>${escapeHtml(item.status || '—')} • ${escapeHtml(item.resourceType || 'other')} • ${escapeHtml(new Date(item.savedAt).toLocaleString())}</small></div>
      <div class="saved-actions">
        <button class="btn btn-outline small restore-saved" data-id="${escapeHtml(item.id)}">Open</button>
        <button class="btn btn-outline small danger delete-saved" data-id="${escapeHtml(item.id)}">Hapus</button>
      </div>
    </article>`).join('');
}

function restoreSaved(id) {
  const snapshot = state.saved.find(item => item.id === id);
  if (!snapshot) return;
  const record = snapshotToRecord(snapshot);
  state.records.unshift(record);
  setSelected(record.id);
  document.getElementById('generatorSection').scrollIntoView({ behavior: 'smooth', block: 'start' });
  showToast('Saved snapshot dibuka sebagai request lokal.');
}

function exportSanitized() {
  const payload = state.records.map(recordSnapshot);
  downloadText(`network-script-studio-${Date.now()}.json`, JSON.stringify(payload, null, 2), 'application/json;charset=utf-8');
  showToast('Export JSON tersensor dibuat.');
}

function renderAll() {
  renderStats();
  renderList();
  renderDetailMeta();
  renderActiveTab();
  generateCode();
}

function setupEvents() {
  $('#refreshBtn').addEventListener('click', loadHar);
  $('#clearBtn').addEventListener('click', clearRecords);
  $('#captureBtn').addEventListener('click', () => {
    state.capturing = !state.capturing;
    $('#captureBtn').textContent = state.capturing ? '● Capture aktif' : '○ Capture berhenti';
    $('#captureBtn').classList.toggle('btn-primary', state.capturing);
    $('#captureBtn').classList.toggle('btn-outline', !state.capturing);
    renderStats();
    showToast(state.capturing ? 'Capture real-time diaktifkan.' : 'Capture real-time dihentikan.');
  });
  $('#searchInput').addEventListener('input', renderList);
  $('#methodFilter').addEventListener('change', renderList);
  $('#statusFilter').addEventListener('change', renderList);
  $('#exportBtn').addEventListener('click', exportSanitized);

  $('#requestTableBody').addEventListener('click', event => {
    const target = event.target.closest('[data-id]');
    if (!target) return;
    setSelected(target.dataset.id);
  });

  $$('.tab').forEach(tab => tab.addEventListener('click', () => {
    state.activeTab = tab.dataset.tab;
    $$('.tab').forEach(item => item.classList.toggle('active', item === tab));
    renderActiveTab();
  }));

  $('#saveBtn').addEventListener('click', saveCurrent);
  $('#generateJumpBtn').addEventListener('click', () => {
    document.getElementById('generatorSection').scrollIntoView({ behavior: 'smooth', block: 'start' });
    generateCode();
  });
  $('#generateBtn').addEventListener('click', generateCode);
  ['languageSelect', 'classNameInput', 'safeHeadersToggle', 'sampleParseToggle'].forEach(id => {
    $(`#${id}`).addEventListener(id === 'classNameInput' ? 'input' : 'change', generateCode);
  });
  $('#copyCodeBtn').addEventListener('click', () => copyText(state.generatedCode));
  $('#downloadCodeBtn').addEventListener('click', () => {
    downloadText(filenameForCode(), state.generatedCode, mimeForCode());
    showToast('File kode dibuat.');
  });

  $('#clearSavedBtn').addEventListener('click', clearSaved);
  $('#savedList').addEventListener('click', event => {
    const button = event.target.closest('button[data-id]');
    if (!button) return;
    if (button.classList.contains('restore-saved')) restoreSaved(button.dataset.id);
    if (button.classList.contains('delete-saved')) removeSaved(button.dataset.id);
  });

  $$('.nav-link[data-scroll]').forEach(button => button.addEventListener('click', () => {
    const target = document.getElementById(button.dataset.scroll);
    if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    $$('.nav-link').forEach(item => item.classList.toggle('active', item === button));
  }));
  $('#savedNav').addEventListener('click', () => document.getElementById('savedSection').scrollIntoView({ behavior: 'smooth', block: 'start' }));
}

function init() {
  setupEvents();
  loadSaved();
  chrome.devtools.network.onRequestFinished.addListener(entry => {
    if (state.capturing) addRecord(entry);
  });
  loadHar();
}

init();
