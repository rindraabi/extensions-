chrome.devtools.panels.create(
  'Network Script Studio',
  '',
  'panel.html',
  () => {}
);
