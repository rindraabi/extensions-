# Network Script Studio

Chrome DevTools extension (Manifest V3) untuk melihat HAR/network request pada tab yang sedang diinspeksi dan membuat template PHP cURL, Python `requests`, atau cURL command.

## Privasi dan batasan

- Semua pemrosesan berjalan di browser secara lokal. Extension ini **tidak memiliki server backend**.
- Nilai `Cookie`, `Set-Cookie`, `Authorization`, token, API key, password, session, signature, dan parameter yang terdeteksi rahasia selalu disamarkan pada UI, saved request, export JSON, dan kode hasil generator.
- Extension ini **tidak meminta izin `cookies` atau host permission** dan tidak mengekstrak cookie browser.
- Response body bisa tidak tersedia untuk sebagian request. Buka DevTools terlebih dahulu, kemudian reload halaman target dan capture ulang.
- Gunakan hanya untuk API/domain yang Anda miliki atau telah mendapat izin tertulis untuk diuji.

## Instalasi

1. Ekstrak folder `network-script-studio`.
2. Buka Chrome desktop lalu akses `chrome://extensions`.
3. Aktifkan **Developer mode**.
4. Klik **Load unpacked**.
5. Pilih folder `network-script-studio`.
6. Buka website/API yang akan diuji pada Chrome desktop.
7. Tekan `F12` atau `Ctrl+Shift+I` untuk membuka DevTools.
8. Pilih tab **Network Script Studio**.
9. Reload halaman target agar request awal juga terbaca.

## Cara menggunakan

1. Pilih request dari tabel.
2. Buka tab `Headers`, `Payload`, `Preview`, `Response`, `Cookies`, atau `Timing`.
3. Gulir ke `Script generator`.
4. Pilih `PHP cURL Class`, `Python 3 requests Class`, atau `cURL Command`.
5. Tentukan nama class lalu klik **Generate**.
6. Copy atau download kode.

## Catatan PHP

Kode PHP yang dihasilkan memakai cURL dengan validasi SSL aktif:

```php
CURLOPT_SSL_VERIFYPEER => true,
CURLOPT_SSL_VERIFYHOST => 2,
```

Jangan menonaktifkan verifikasi SSL pada aplikasi produksi.

## Struktur file

```text
network-script-studio/
├── manifest.json
├── devtools.html
├── devtools.js
├── panel.html
├── panel.css
├── panel.js
├── popup.html
├── README.md
└── icons/
```
